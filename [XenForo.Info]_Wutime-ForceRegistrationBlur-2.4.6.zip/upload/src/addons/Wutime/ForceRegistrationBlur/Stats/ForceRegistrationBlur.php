<?php

namespace Wutime\ForceRegistrationBlur\Stats;

use XF\Stats\AbstractHandler;

class ForceRegistrationBlur extends AbstractHandler
{
    public function getStatsTypes()
    {
        return [
            'frb_users' => \XF::phrase('wutime_frb_user_registrations'),
            'frb_upgrades' => \XF::phrase('wutime_frb_user_upgrades'),
        ];
    }

    public function getData($start, $end)
    {
        $db = $this->db();

		$usersFrbUpgrades = $this->db()->fetchPairs(
			$this->getBasicDataQuery('xf_wutime_frb_user_upgrade', 'created'),
			[$start, $end]
		);

        $usersFrbRegistered = $db->fetchPairs(
            "
                SELECT 
                    FLOOR(xf_user.register_date / 86400) * 86400 AS stat_date, 
                    COUNT(*) AS total
                FROM 
                    xf_user
                INNER JOIN 
                    xf_wutime_frb_user ON xf_user.user_id = xf_wutime_frb_user.user_id
                WHERE 
                    xf_user.register_date BETWEEN ? AND ?
                GROUP BY 
                    stat_date
            ",
            [$start, $end]
        );

        return [
            'frb_users' => $usersFrbRegistered,
            'frb_upgrades' => $usersFrbUpgrades,
        ];
    }
}
