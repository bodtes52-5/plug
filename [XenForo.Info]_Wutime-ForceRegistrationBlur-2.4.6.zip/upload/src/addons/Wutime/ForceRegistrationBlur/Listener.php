<?php

namespace Wutime\ForceRegistrationBlur;

use Jaybizzle\CrawlerDetect\CrawlerDetect;

class Listener
{   
    static $crawlerDetect = [];

    public static function templaterMacroPreRender(\XF\Template\Templater $templater, &$type, &$template, &$name, array &$arguments, array &$globalVars)
    {
        if (!empty($arguments['group']) && $arguments['group']->group_id == 'wutime_forceregblur_option_group')
        {
            // Override template name
            $template = 'wutime_forcereg_option_macros';

            if (!\XF::options()->wutime_forcereg_use_option_tabs) {
                // Or use 'option_form_block_tabs' for tabs
                $name = 'option_form_block';
            } else {
                // Or use 'option_form_block_tabs' for tabs
                $name = 'option_form_block_tabs';
            }

            // Your block header configurations
            $arguments['headers'] = [
                'generalOptions'      => [
                    'label'           => \XF::phrase('general_options'),
                    'minDisplayOrder' => 0,
                    'maxDisplayOrder' => 1000,
                    'active'          => true // Only used for tabs, indicates default active tab
                ],
                'guestMode'        => [
                    'label'           => \XF::phrase('guest'),
                    'minDisplayOrder' => 1000,
                    'maxDisplayOrder' => 2000
                ],
                'guestOptions' => [
                    'label'           => \XF::phrase('guest') . " " . \XF::phrase('options'),
                    'minDisplayOrder' => 2000,
                    'maxDisplayOrder' => 3000
                ],
                'userOptions'        => [
                    'label'           => \XF::phrase('user'). " " . \XF::phrase('options'),
                    'minDisplayOrder' => 4000,
                    'maxDisplayOrder' => 5000
                ],
                'displayConditions'    => [
                    'label'           => \XF::phrase('display_condition'),
                    'minDisplayOrder' => 5000,
                    'maxDisplayOrder' => 6000
                ],
                'appearance'        => [
                    'label'           => \XF::phrase('option_group.appearance'),
                    'minDisplayOrder' => 8000,
                    'maxDisplayOrder' => 9000
                ],
                'displayAQ'    => [
                    'label'           => \XF::phrase('thread_type.article') . '/' . \XF::phrase('thread_type.question'),
                    'minDisplayOrder' => 6000,
                    'maxDisplayOrder' => 8000
                ],
                'evenMoreOptions'     => [
                    'label'           => \XF::phrase('advanced_options'),
                    'id'              => 'option-advanced',
                    'minDisplayOrder' => 9000,
                    'maxDisplayOrder' => -1 // This allows for any higher display order value
                ],
            ];
        }
    }
}

