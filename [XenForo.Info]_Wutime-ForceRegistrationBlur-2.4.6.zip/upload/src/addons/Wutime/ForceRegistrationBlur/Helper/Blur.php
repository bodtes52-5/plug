<?php

namespace Wutime\ForceRegistrationBlur\Helper;

use Wutime\ForceRegistrationBlur\Entity\FrbUserThread;
use Jaybizzle\CrawlerDetect\CrawlerDetect;

class Blur {

    // Define the static variable for BBCode pattern
    private static $bbcodePattern = '/(\[.*?\])/s';

    public static function determineIsBlurForum(int $node_id) {

        $options = \XF::options();
        $visitor = \XF::visitor();

        // logic to determine if the post should be blurred
        if (!$visitor->hasNodePermission($node_id, 'viewUnblurredContent')
            && ((bool)$options->wutime_forceregblur_enable)
            && $options->wutime_frb_implementation != 'Guests') 
        {
            return true;

        } else {
           return false; 
        }
    }


	public static function determineIsBlur(?int $node_id, bool $sticky = null): bool
	{
	    $options = \XF::options();
	    $visitor = \XF::visitor();


	    // If node_id is null (e.g., during new thread creation), don't blur
	    if ($node_id === null) {
	        return false;
	    }

	    // Logic to determine if the post should be blurred
	    if ((!$visitor->hasNodePermission($node_id, 'viewUnblurredContent')
	        && ($sticky === null || !($sticky && $visitor->hasNodePermission($node_id, 'viewUnblurredStickies')))
	        && ((bool)$options->wutime_forceregblur_enable)
	        && $options->wutime_frb_implementation == 'Users')
	    	)
	    {
	    	// never blur for guests if it's a crawler with options enabled
	    	if ($options->wutime_forceregblur_do_not_blur_crawlers && $visitor->user_id == 0) {
			    $CrawlerDetect = new CrawlerDetect;
			   	if($CrawlerDetect->isCrawler()) {
		            return false;
		        }
	    	}

	    	// blurring
	        return true;
	    }

	    return false;
	}

	public static function determineIsBlurDebugging(\XF\Entity\Thread $thread)
	{
	    if (\XF::$debugMode && isset(\XF::options()->wutime_frb_debug) && \XF::options()->wutime_frb_debug) {
	        $visitor = \XF::visitor();
	        $session = \XF::session();
	        $options = \XF::options();

	        // Get the isBlur result using node_id
	        $nodeId = $thread->node_id;
	        $isBlur = self::determineIsBlur($nodeId, $thread->sticky);

	        // Break down reasons if false, matching determineIsBlur logic with node_id
	        $reasons = [];
	        if (!$isBlur) {
	            if ($nodeId === null) {
	                $reasons[] = "Failed: node_id is null";
	            }
	            if ($visitor->hasNodePermission($nodeId, 'viewUnblurredContent')) {
	                $reasons[] = "Failed: User has viewUnblurredContent permission (node_id: $nodeId)";
	            }
	            if ($thread->sticky && $visitor->hasNodePermission($nodeId, 'viewUnblurredStickies')) {
	                $reasons[] = "Failed: Thread is sticky and user has viewUnblurredStickies permission (node_id: $nodeId)";
	            }
	            if (!((bool)$options->wutime_forceregblur_enable)) {
	                $reasons[] = "Failed: wutime_forceregblur_enable is not enabled";
	            }
	            if ($options->wutime_frb_implementation == 'Guests') {
	                $reasons[] = "Failed: wutime_frb_implementation is set to 'Guests'";
	            }
	        }

	        $testArray = [
	            'wutime_forceregblur_enable' => $options->wutime_forceregblur_enable,
	            'wutime_frb_implementation' => $options->wutime_frb_implementation,
	            '$visitor->user_id' => $visitor->user_id,
	            'session' => $session->get('wutime_frb_user_blur_data'),
	            '$this->thread_id' => $thread->thread_id,
	            '$this->nodeid' => $thread->node_id,
	            '$this->sticky' => $thread->sticky,
	            'hasNodePerm viewUnblurredContent' => $visitor->hasNodePermission($thread->node_id, 'viewUnblurredContent'),
	            'hasNodePerm viewUnblurredStickies' => $visitor->hasNodePermission($thread->node_id, 'viewUnblurredStickies'),
	            'hasNodePerm viewUnblurredPosts' => $visitor->hasNodePermission($thread->node_id, 'viewUnblurredPosts'),
	            'hasNodePerm viewUnblurredParagraphs' => $visitor->hasNodePermission($thread->node_id, 'viewUnblurredParagraphs'),
	            'isBlur' => $isBlur,
	            'isBlur_reasons' => $isBlur ? 'Passed: Content Blurred' : $reasons,
	            'thread' => $thread,
	            'visitor' => $visitor,
	        ];

	        \XF::dump($testArray);
	        \XF::dump(\XF::session()->get('wutime_frb_user_blur_data'));
	    }
	}

	public static function recordThreadView(?int $threadId)
	{
	    if ($threadId === null) {
	        return; // Exit early during thread creation
	    }
        $visitor = \XF::visitor();

        if ($visitor->user_id > 0) {
            FrbUserThread::saveThreadView($threadId);

        }

        Blur::updateBlurSessionThreadView($threadId);
    }

	public static function recordUpgradeView()
	{

        // let's record the account upgrade visit
        Blur::updateBlurSessionUpgradeVisit(self::getLastThreadId());

        FrbUserThread::saveUpgradeView(self::getLastThreadId());

    } 

    protected static function getBlurSessionDefault()
    {
        return [
            'view_count' => 0, 
            'thread_views' => [], 
            'last_thread_id' => 0,
            'upgrade_count' => 0, 
            'upgrade_views' => [],
            'last_thread_id_upgrade' => 0,
        ];
    }

    public static function getBlurData() 
    {
        $blurData = \XF::session()->get('wutime_frb_user_blur_data') ?: self::getBlurSessionDefault();
        return $blurData;
    }

    public static function getViewCount()
    {
        return self::getBlurDataValue('view_count');
    }

    public static function getLastThreadId()
    {
        return self::getBlurDataValue('last_thread_id');
    }

    public static function getLastThreadUpgradeId()
    {
        return self::getBlurDataValue('last_thread_id_upgrade');
    }


    private static function getBlurDataValue($key)
    {
        $blurData = \XF::session()->get('wutime_frb_user_blur_data') ?: self::getBlurSessionDefault();
        return ($blurData[$key] > 0) ? $blurData[$key] : false;
    }

    public static function updateBlurSessionThreadView($threadId)
    {
        self::updateBlurSession('thread_views', 'view_count', 'last_thread_id', $threadId);
    }

    public static function updateBlurSessionUpgradeVisit($threadId)
    {
        $session = \XF::session();
        $blurData = $session->get('wutime_frb_user_blur_data') ?: self::getBlurSessionDefault();

        if ($blurData['view_count'] > 0) {
            self::updateBlurSession('upgrade_views', 'upgrade_count', 'last_thread_id_upgrade', $threadId);
        }
    }

    private static function updateBlurSession($viewKey, $countKey, $lastIdKey, $threadId)
    {
        $session = \XF::session();
        $blurData = $session->get('wutime_frb_user_blur_data') ?: self::getBlurSessionDefault();

        // Increment the global count
        $blurData[$countKey]++;

        // Increment the count for the specific thread
        if (!isset($blurData[$viewKey][$threadId])) {
            $blurData[$viewKey][$threadId] = 0;
        }

        $blurData[$viewKey][$threadId]++;
        $blurData[$lastIdKey] = $threadId;

        // Update the session variable
        $session->set('wutime_frb_user_blur_data', $blurData);

        // Save the session
        $session->save();
    }

    public static function shiftLettersIfUser($input) {
        $options = \XF::options();
        $visitor = \XF::visitor();

		if ($options->wutime_forceregblur_user_osbfucate_post_text && $visitor->user_id > 0) {
			$input = self::shiftLetters($input);
		} elseif ($options->wutime_forceregblur_guest_osbfucate_post_text && $visitor->user_id == 0) {

			// never obfuscate for crawlers!!
			if ($options->wutime_forceregblur_do_not_blur_crawlers) {
			    $CrawlerDetect = new CrawlerDetect;
			   	if($CrawlerDetect->isCrawler()) {
		            return $input;
		        }
			}

			// obfuscate
			$input = self::shiftLetters($input);
		}

		return $input;

    }

    public static function shiftLetters($input) 
    {
        // Regular expression patterns for [URL], [MEDIA], and [ATTACH] tags
        $urlPattern = '\[URL(?:[^\]]*)?\].*?\[\/URL\]';
        $mediaPattern = '\[MEDIA(?:[^\]]*)?\].*?\[\/MEDIA\]';
        $attachPattern = '\[ATTACH(?:[^\]]*)?\].*?\[\/ATTACH\]';
        $bbTagPattern = '\[(?:\/)?[a-z0-9_-]+(?:=[^\]\r\n]+)?\]';
        $textPattern = '[^[]+';
		$htmlTagPattern = '<[^>]*?>';

        // Check if we need to remove images
        $imgPattern = '/\[IMG(?:[^\]]*)?\].*?\[\/IMG\]/is';
        if (\XF::options()->wutime_forcegreg_remove_images) {
            // Remove all [IMG] and [ATTACH] BBCode tags and their content
            $input = preg_replace([$imgPattern, "/$attachPattern/is"], '', $input);
        }

        // Check if we need to remove links
        if (\XF::options()->wutime_forcegreg_remove_links) {
            // Remove all [URL] BBCode tags and their content
            $input = preg_replace("/$urlPattern/is", '', $input);
        }

        // Use preg_replace_callback to process text and preserve [URL], [MEDIA], and [ATTACH] tags
		$input = preg_replace_callback(
		    "/($urlPattern|$mediaPattern|$attachPattern|$bbTagPattern|$htmlTagPattern)|([^<\[]+)/is",
		    function ($matches) {
		        if (!empty($matches[1])) {
		            // any preserved block or tag — return as-is
		            return $matches[1];
		        }
		        // plain text between tags — obfuscate
		        return self::shiftText($matches[2]);
		    },
		    $input
		);

        return $input;
    }





    private static function shiftText($text) 
    {
        // Define the vowels and their mappings
        $vowels = ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'];
        $nextVowel = [
            'a' => 'e', 'e' => 'i', 'i' => 'o', 'o' => 'u', 'u' => 'a',
            'A' => 'E', 'E' => 'I', 'I' => 'O', 'O' => 'U', 'U' => 'A'
        ];

        // Define the consonants and their mappings
        $consonants = [
            'b' => 'c', 'c' => 'd', 'd' => 'f', 'f' => 'g', 'g' => 'h', 'h' => 'j', 'j' => 'k',
            'k' => 'l', 'l' => 'm', 'm' => 'n', 'n' => 'p', 'p' => 'q', 'q' => 'r', 'r' => 's',
            's' => 't', 't' => 'v', 'v' => 'w', 'w' => 'x', 'x' => 'y', 'y' => 'z', 'z' => 'b',
            'B' => 'C', 'C' => 'D', 'D' => 'F', 'F' => 'G', 'G' => 'H', 'H' => 'J', 'J' => 'K',
            'K' => 'L', 'L' => 'M', 'M' => 'N', 'N' => 'P', 'P' => 'Q', 'Q' => 'R', 'R' => 'S',
            'S' => 'T', 'T' => 'V', 'V' => 'W', 'W' => 'X', 'X' => 'Y', 'Y' => 'Z', 'Z' => 'B'
        ];

        // Convert the input string to an array of characters
        $chars = mb_str_split($text);

        // Shift each character as needed
        foreach ($chars as &$char) {
            if (in_array($char, $vowels)) {
                $char = $nextVowel[$char];
            } elseif (isset($consonants[$char])) {
                $char = $consonants[$char];
            }
        }

        // Join the characters back into a string and return
        return implode('', $chars);
    }


 	public static function trimMessageByPercentage($message, $amount) 
	{
	    // Ensure amount is between 1 and 100
	    if ($amount < 1 || $amount > 100) 
	    {
	        throw new InvalidArgumentException("Amount must be between 1 and 100");
	    }

	    // Check if message is not empty
	    if (!empty($message)) 
	    {
	        // Calculate the percentage to trim
	        $percentage = $amount * 0.01;

	        // Calculate the length of the trimmed message
	        $trimmedLength = floor(strlen($message) * $percentage);

	        // Return the trimmed message
	        return substr($message, 0, $trimmedLength);
	    } 
	    else 
	    {
	        // If message is empty, return an empty string or handle as needed
	        return '';
	    }
	}
}
