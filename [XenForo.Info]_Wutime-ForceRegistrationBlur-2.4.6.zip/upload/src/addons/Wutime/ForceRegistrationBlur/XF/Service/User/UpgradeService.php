<?php

namespace Wutime\ForceRegistrationBlur\XF\Service\User;

use XF\Service\User\UpgradeService as BaseUpgradeService;
use Wutime\ForceRegistrationBlur\Helper\Blur;
use Wutime\ForceRegistrationBlur\Entity\FrbUserThread;

class UpgradeService extends XFCP_UpgradeService
{
    public function upgrade()
    {
        // Call the parent upgrade method and get the result
        $result = parent::upgrade();

        // Custom logic to check if the upgrade is new
        $this->checkAndSaveFrbData();

        // Return the result of the parent method
        return $result;
    }

    protected function checkAndSaveFrbData()
    {
        $userId = $this->user->user_id;
        $userUpgradeId = $this->userUpgrade->user_upgrade_id;

        $this->saveNewFrbUserUpgrade($userId, $userUpgradeId);
    }

    protected function saveNewFrbUserUpgrade($userId, $userUpgradeId)
    {
        if ($lastThreadId = FrbUserThread::getMostRecentlyModifiedUpgradeViewThreadId()) {
            // Create and save your custom entity
            $frbUserUpgrade = $this->em()->create('Wutime\ForceRegistrationBlur:FrbUserUpgrade');
            $frbUserUpgrade->user_id = $userId;
            $frbUserUpgrade->user_upgrade_id = $userUpgradeId;
            $frbUserUpgrade->thread_id = $lastThreadId; // Set thread_id appropriately
            $frbUserUpgrade->cost_amount = $this->userUpgrade->cost_amount;
            $frbUserUpgrade->created = \XF::$time;
            $frbUserUpgrade->save();
        }
    }
}
