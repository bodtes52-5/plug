<?php

namespace Wutime\ForceRegistrationBlur\XF\Pub\Controller;

use XF\Mvc\Reply\View;
use Wutime\ForceRegistrationBlur\Helper\Blur;


class Account extends XFCP_Account
{

    public function actionUpgrades()
    {
    	$options = \XF::options();
     
        $response = parent::actionUpgrades();

        if (!($response instanceof View) || !$options->wutime_forceregblur_enable) {
        	return $response;
        }

        // let's record the account upgrade visit
        Blur::recordUpgradeView();

        return $response;
    }

}
