<?php

namespace Wutime\ForceRegistrationBlur\XF\Pub\Controller;

use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\View;
use Wutime\ForceRegistrationBlur\Helper\Blur;

class Post extends XFCP_Post
{

    public function actionIndex(ParameterBag $params)
    {
        $response = parent::actionIndex($params);

        $options = \XF::options();

        // We only deal with View
        if ($response instanceof View && $options->wutime_forceregblur_enable) {

            $post = $response->getParam('post');
            if ($post) {
                $thread = $post->Thread;
                if ($thread) {
                    $thread->determineBlur();
                }
            }
        }

        return $response;
    }

}
