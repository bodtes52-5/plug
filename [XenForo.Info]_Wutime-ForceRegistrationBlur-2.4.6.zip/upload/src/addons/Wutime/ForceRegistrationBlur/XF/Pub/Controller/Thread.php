<?php

namespace Wutime\ForceRegistrationBlur\XF\Pub\Controller;

use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\View;
use Wutime\ForceRegistrationBlur\Helper\Blur;
use Jaybizzle\CrawlerDetect\CrawlerDetect;

class Thread extends XFCP_Thread
{

	private static $post_index 		= 0;
    private static $post_notices 	= 0;
    private static $total_posts    	= 0;
    private static $postsNoticed	= [];


    public function actionIndex(ParameterBag $params)
    {
     
        $response = parent::actionIndex($params);

        $options = \XF::options();
        $visitor = \XF::visitor();

        // we only deal with View
        if (!($response instanceof View && ($thread = $response->getParam('thread')))) {
        	return $response;
        }

        // exit if disabled addon
        if (!$options->wutime_forceregblur_enable) {
        	return $response;
        }

	    if ( $options->wutime_frb_implementation == 'Guests'
	    	&& ($visitor->user_id == 0 || $visitor['is_banned'] || $visitor['user_state'] != 'valid' )) {

			///////////////////////////////////////////////////////////////////
	    	///////////////////////////////////////////////////////////////////
	    	//////// GUESTS MODE //////////////////////////////////////////////
	    	///////////////////////////////////////////////////////////////////
	    	///////////////////////////////////////////////////////////////////


			// exit if we don't want to blur crawlers
			if ($options->wutime_forceregblur_do_not_blur_crawlers 
			    && ($visitor->user_id == 0 || !$options->wutime_forceregblur_ignore_crawlers_masquerading)) {

			    $CrawlerDetect = new CrawlerDetect;

			   	if($CrawlerDetect->isCrawler()) {
		            return $response;
		        }
			}

	        // ignore stickies
	        if ($options->wutime_forceregblur_ignore_sticky and $thread->sticky) {
	            return $response;
	        }

	        // ignore forums
	        if (in_array($thread->node_id, $options->wutime_forceregblur_exclude_forums)) {

		        // check if we're on an included thread_id
		        if (!empty($options->wutime_forceregblur_include_thread_ids)) {
		        	// check for thread_id
		        	if (!in_array($thread->thread_id, explode(',', $options->wutime_forceregblur_include_thread_ids))) {
		        		return $response;
		        	}
		        } else {
		        	return $response;
		        }
	        }

	       	// articles (special replace)
	       	if ($thread->discussion_type === 'article') {
				if ($response->getParam('firstPost')->message) {
					if ($options->wutime_forceregblur_articles_on) {

						$post = $response->getParam('firstPost');

						// search pattern
						$pattern = sprintf("/(.*\n\n){1,%d}/", $options->wutime_forceregblur_articles_sentences);

						if ($options->wutime_forceregblur_articles_sentences && preg_match($pattern, $post->message, $match)) {
								$post->message = "[wutime_forcereg_fade]".$match[0]."[/wutime_forcereg_fade]";
						} else {


							if ($options->wutime_forceregblur_guest_osbfucate_post_text) {
								$post->message  = Blur::shiftLetters($post->message);
							}
							// fade post
	       					self::blurPost($post);
						}

	       				// click registration link
	       				self::showRegistrationOrEmailConfirm($post);
					}
            	}
			} elseif ( $thread->discussion_type === 'question' ) {

				if ($response->getParam('firstPost')->message) {

					$post = $response->getParam('firstPost');

					if (self::$post_index >= $options->wutime_forceregblur_do_not_blur_x_posts ) {

						if ($options->wutime_forceregblur_guest_osbfucate_post_text) {
							$post->message  = Blur::shiftLetters($post->message);
						}
						// fade post
	   					self::blurPost($post);
	       				// click registration link
	       				self::showRegistrationOrEmailConfirm($post);
	       			}

					self::$post_index++;

				}

			}

			// set posts
			$posts = $response->getParam('posts');

        	// set total posts
			self::$total_posts = count($posts);

			// iterate regular posts
	       	foreach ($posts as $post) {

   				self::$post_index++;

   				//$post->setBlur(true);

   				if (self::$post_index > $options->wutime_forceregblur_do_not_blur_x_posts ) 
   				{

	   				if ($thread->discussion_type === 'question'
	   					&& $thread->type_data['solution_post_id'] 
	   					&& $thread->type_data['solution_post_id'] === $post->post_id
	   					&& !$options->wutime_forcereg_always_blur_solution) {
	   					continue;
	   				}

					if ($options->wutime_forceregblur_guest_osbfucate_post_text) {
						$post->message  = Blur::shiftLetters($post->message);
					}

   					// blur post
   					self::blurPost($post);		       					

   					// update the post
   					if ($options->wutime_forceregblur_registration_message ) {
   						self::showRegistrationOrEmailConfirm($post);
   					}

   				}
   			}

   			if (count(self::$postsNoticed) > 0) {
   				Blur::recordThreadView($thread->thread_id);
   			}
   			
   			// add to last post
   			if ($options->wutime_forceregblur_always_notice_last_post) {
   				self::showRegistrationOrEmailConfirm($post, $force=true);
   			}

			// registration overlay trigger
			self::decideShowRegistrationTrigger($post);

        } 
        elseif ($options->wutime_frb_implementation == 'Users') 
        {

		///////////////////////////////////////////////////////////////////
    	///////////////////////////////////////////////////////////////////
    	//////// USERS MODE ///////////////////////////////////////////////
    	///////////////////////////////////////////////////////////////////
    	///////////////////////////////////////////////////////////////////


        	// get perms
			$viewUnblurredPosts = $visitor->hasNodePermission($thread->node_id, 'viewUnblurredPosts');
			$fadeParagraphs = $visitor->hasNodePermission($thread->node_id, 'viewUnblurredParagraphs');

			// exit if we don't want to blur crawlers
			if ($visitor->user_id && !$options->wutime_forceregblur_ignore_crawlers_masquerading) {
			    $CrawlerDetect = new CrawlerDetect;
			   	if($CrawlerDetect->isCrawler()) {
		            return $response;
		        }
			}


	        // setup blur for users
	        $thread->determineBlur();


	        // exit if we're not blur
	        if (!$thread->isBlur()) {
	        	return $response;
	        }

	        // ignore stickies if permission set
        	if ($thread->sticky && $visitor->hasNodePermission($thread->node_id, 'viewUnblurredStickies')) {       		
        		return $response;
        	}

			$prms = $response->getParams();


	       	// articles (special replace)
	       	if ($thread->discussion_type === 'article') {

				if ($response->getParam('firstPost')->message) {

					$post = $response->getParam('firstPost');

					if ($fadeParagraphs > 0) {
						$pattern = sprintf("/(.*\n\n){1,%d}/", $fadeParagraphs);

						if (preg_match($pattern, $post->message, $match)) {
						    // Store the original message before modifying
						    $originalMessage = $post->message;
						    
						    // Fade the matched part (first $fadeParagraphs paragraphs)
						    $fadedPart = $match[0];
						    $post->message = "[wutime_forcereg_fade]" . $fadedPart . "[/wutime_forcereg_fade]";

						    if ($options->wutime_forcereg_fade_show_full_article) {
							    // Get the remaining text after the faded part from the original message
							    $postPartNotHighlighted = substr($originalMessage, strlen($fadedPart));
							    
							    $postPartNotHighlighted  = Blur::shiftLettersIfUser($postPartNotHighlighted);

							    $post->message .= self::blurPostPart($postPartNotHighlighted);
						    }

						}

						$post->setOption('frb_is_blur_first_post', true);
					// Unlimited "unblurred" posts
					} elseif ($fadeParagraphs === -1) {

						$post->message = "[wutime_forcereg_fade]" . $post->message . "[/wutime_forcereg_fade]";

						$post->setOption('frb_is_blur_first_post', true);

					// Fade not selected
					} else {

						if (self::$post_index >= $viewUnblurredPosts) {
							$post->message  = Blur::shiftLettersIfUser($post->message);
							self::blurPost($post);
							$post->setOption('frb_is_blur_first_post', true);
						}

					}
					  
					self::$post_index++;
				}
			} elseif ( $thread->discussion_type === 'question' ) {

				if ($response->getParam('firstPost')->message) {

					$post = $response->getParam('firstPost');

					if (self::$post_index >= $viewUnblurredPosts) {
						$post->message  = Blur::shiftLettersIfUser($post->message);
						self::blurPost($post);
						$post->setOption('frb_is_blur_first_post', true);
					}
				}

				self::$post_index++;

			}




			// posts of -1 (unlimited unblurred posts)
			if ($viewUnblurredPosts !== -1) {
				// set posts
				$posts = $response->getParam('posts');

	   			foreach($posts as $key => $post) {

	   				/*
	   				if ($thread->discussion_type === 'question'
	   					&& $thread->type_data['solution_post_id'] 
	   					&& $thread->type_data['solution_post_id'] === $post->post_id
	   					&& !$options->wutime_forcereg_always_blur_solution) {
	   					continue;
	   				}
	   				*/

	   				self::$post_index++;

	   				if (self::$post_index > $viewUnblurredPosts) 
	   				{

						if ($options->wutime_forceregblur_user_osbfucate_post_text) {
							$post->message  = Blur::shiftLettersIfUser($post->message);
						}


	   					self::blurPost($post);


	   				} 

	   				// first blurred post
					if ((self::$post_index - 1) === $viewUnblurredPosts) {
	   					$post->setOption('frb_is_blur_first_post', true);
	   				}


	   			}	
			}

	       	// registration overlay trigger
			self::decideShowRegistrationTrigger($post);

	    }

        return $response;
    }


    static private function GuestMode(&$response) {
        $options = \XF::options();
        $visitor = \XF::visitor();
    }

    static private function UserMode(&$response) {
        $options = \XF::options();
        $visitor = \XF::visitor();    	
    }

    static public function trimPostToPercentage (&$post) {
    	$post->message = Blur::trimMessageByPercentage($post->message, 20);
    }

    static public function showRegistrationOrEmailConfirm(&$post, $force=false) {

    	$options = \XF::options();
        $visitor = \XF::visitor();

	    // Ensure post_id is set and is not null before proceeding
	    if (isset($post->post_id) && $post->post_id !== null &&
	        (($options->wutime_forceregblur_registration_message_limit > count(self::$postsNoticed) || $force) &&
	        !in_array($post->post_id, self::$postsNoticed))
	    ) {

    		$post->message .= '[wutime_forcereg_notice]';

			if ($visitor->user_id == 0) {

		        $router = \XF::app()->router('public');
		        $loginUrl = $router->buildLink('canonical:login');
		        $registerUrl = $router->buildLink('canonical:register');

		    	$loginLink = "[URL=".$loginUrl."]" . strtolower(\XF::phrase('login')) . "[/URL]";
		    	$registerLink = "[URL=".$registerUrl."]" . strtolower(\XF::phrase('register')) . "[/URL]";

		        // parameters for phrase
		        $phraseParams = ['login' => $loginLink, 'register' => $registerLink];

		        // Fetch the raw template content from the database
		        $noticePhrase = \XF::phrase('wutime_forcereg_blur_please_register_x_or_y_message', $phraseParams);

		        // add bbCode to post->message
				$post->message .= $noticePhrase;

			} elseif (isset($visitor->user_state) 
						&& $visitor->user_state != 'valid' 
						&& ($visitor->user_state == 'email_confirm'
							|| $visitor->user_state == 'email_confirm_edit') ) {

		        // Generate the link for confirmation
		        $router = \XF::app()->router('public');
		        $confirmUrl = $router->buildLink('canonical:account-confirmation/resend');
		        $confirmLink = "[URL=$confirmUrl]" . strtolower(\XF::phrase('confirm_your_email')) . "[/URL]";

		        // Create the phrase with dynamic content
		        $phraseParams = ['confirm_email_link' => $confirmLink];
		        $noticePhrase = \XF::phrase('wutime_forcereg_please_confirm_email_x_to_view_bbcode', $phraseParams);

		        // add bbCode to post->message
				$post->message .= $noticePhrase;

			}

			$post->message .= '[/wutime_forcereg_notice]';

			self::$postsNoticed[] = $post->post_id;

    	}
    }

	static public function decideShowRegistrationTrigger(&$post) {
	    $options = \XF::options();
	    $visitor = \XF::visitor();

	    // click registration link
	    if ($options->wutime_forceregblur_popup_registration && $visitor->user_id == 0) {
	        // Only modify $post->message if it exists
	        if (isset($post->message) && is_string($post->message)) {
	            $post->message .= "[wutime_forcereg_trigger][/wutime_forcereg_trigger]";
	        }
	    }
	}

	static public function blurPost(&$post) {
	    // Only modify $post->message if it exists and is a string
	    if (isset($post->message) && is_string($post->message)) {
	    	$post->setOption('frb_is_blur', true);  
	        $post->message = self::blurPostPart($post->message);
	    }
	}

	static public function blurPostPart($textContent) {
	    return "[wutime_forcereg_blur]" . $textContent . "[/wutime_forcereg_blur]";
	}

	static public function showFadedPost(&$post) {
	    // Only modify $post->message if it exists and is a string
	    if (isset($post->message) && is_string($post->message)) {
	        $post->message = "[wutime_forcereg_fade]" . $post->message . "[/wutime_forcereg_fade]";
	    }
	}



}
