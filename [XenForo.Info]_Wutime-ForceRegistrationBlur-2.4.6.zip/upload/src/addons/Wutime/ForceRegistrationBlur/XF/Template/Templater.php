<?php

namespace Wutime\AdBlock\XF\Template;

use Jaybizzle\CrawlerDetect\CrawlerDetect;


class Templater extends \DigitalPoint\Cloudflare\XF\Template\Templater
{
	public function canEdgeCache()
	{
		if (\XF::options()->wutime_forceregblur_enable 
			&& \XF::options()->wutime_forceregblur_cf_page_caching_disable
			&& \XF::options()->wutime_forceregblur_guest_osbfucate_post_text
			&& \XF::options()->wutime_forceregblur_do_not_blur_crawlers
		) {
			return false;
		}

		return parent::canEdgeCache();
	}
}