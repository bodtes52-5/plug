<?php

namespace Wutime\ForceRegistrationBlur\XF\Entity;

class AbstractEntity extends \XF\Mvc\Entity\Entity
{


}