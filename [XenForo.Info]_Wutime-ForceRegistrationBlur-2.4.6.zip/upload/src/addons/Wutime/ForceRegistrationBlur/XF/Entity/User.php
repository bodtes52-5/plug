<?php

namespace Wutime\ForceRegistrationBlur\XF\Entity;

use XF\Mvc\Entity\Structure;
use Wutime\ForceRegistrationBlur\Helper\Blur;

class User extends XFCP_User
{
    protected function _postSave()
    {
        parent::_postSave();
        if ($this->isInsert()) {
            $this->saveFrbUserEntity();
        }
    }

    protected function saveFrbUserEntity()
    {
        if (Blur::getViewCount()) {
            $em = \XF::em();
            $FrbUserEntity = $em->create('Wutime\ForceRegistrationBlur:FrbUser');
            $FrbUserEntity->user_id = $this->user_id;
            $FrbUserEntity->thread_id = Blur::getLastThreadId();
            $FrbUserEntity->blur_count = Blur::getViewCount();
            $FrbUserEntity->blur_data = json_encode(Blur::getBlurData());
            $FrbUserEntity->save();
        }
    }


    protected function _preDelete()
    {
        parent::_preDelete();

        // Delete related records
        $db = \XF::db();
        $db->delete('xf_wutime_frb_user_upgrade', 'user_id = ?', $this->user_id);
        $db->delete('xf_wutime_frb_user_thread', 'user_id = ?', $this->user_id);
        $db->delete('xf_wutime_frb_user', 'user_id = ?', $this->user_id);
    }

}
