<?php

namespace Wutime\ForceRegistrationBlur\XF\Entity;

use XF\Mvc\Entity\Structure;
use Wutime\ForceRegistrationBlur\Helper\Blur;

class Thread extends XFCP_Thread
{
    // Add your custom property
    protected $blur; // Initialize with a default value

    // Getter for the custom property
	public function isBlur()
	{
	    if ($this->blur === null) {
	        $this->determineBlur();
	    }
	    return $this->blur;
	}

    public function getWutimeIsBlur(): bool
    {
        return (bool) $this->isBlur();
    }

    public static function getStructure(Structure $structure)
    {
        $structure = parent::getStructure($structure);

        // Register the getter with caching disabled
        $structure->getters['wutime_is_blur'] = [
            'getter' => 'getWutimeIsBlur', // Corrected key: 'getter' instead of 'method'
            'cache' => false // Disable caching due to user-specific logic
        ];

        return $structure;
    }

    // Setter for the custom property
    public function setBlur($blur)
    {
        $this->blur = $blur;
    }

    public function determineBlur()
    {
        $visitor = \XF::visitor();

        Blur::determineIsBlurDebugging($this);

        if (Blur::determineIsBlur($this->node_id, $this->sticky)) 
        {
            $this->setBlur(true);
            Blur::recordThreadView($this->thread_id);

            return true;
        }

        $this->setBlur(false);
        return false;
    }

    public function canReply(&$error = null)
    {
        $canReply = parent::canReply($error);

        if ($this->isBlur() && \XF::options()->wutime_frb_remove_actions_thread) {
            return false;
        }

        return $canReply;
    }

    public function canDownvoteContent(&$error = null): bool
    {
        $canDownvote = parent::canDownvoteContent($error);

        if ($this->isBlur() && \XF::options()->wutime_frb_remove_actions_thread) {
            return false;
        }

        return $canDownvote;
    }


    public function canReplyPreReg()
    {
        if (\XF::visitor()->user_id || $this->canReply()) {
            // quick bypass with the user ID check, then ensure that this can only return true if the visitor
            // can't take the "normal" action
            return false;
        }

        return \XF::canPerformPreRegAction(function () {
            return $this->canReply();
        });
    }

    public function canDelete($type = 'soft', &$error = null)
    {
        $canDelete = parent::canDelete($type, $error);

        if ($this->isBlur() && \XF::options()->wutime_frb_remove_actions_thread) {
            return false;
        }

        return $canDelete;
    }

    public function canCreatePoll(&$error = null)
    {
        $canCreatePoll = parent::canCreatePoll($error);

        if ($this->isBlur() && \XF::options()->wutime_frb_remove_actions_thread) {
            return false;
        }

        return $canCreatePoll;
    }

    public function canViewAttachments(&$error = null)
    {
        $canViewAttachments = parent::canViewAttachments($error);

        if ($this->isBlur() && \XF::options()->wutime_frb_remove_actions_thread) {
            return false;
        }

        return $canViewAttachments;
    }
}
