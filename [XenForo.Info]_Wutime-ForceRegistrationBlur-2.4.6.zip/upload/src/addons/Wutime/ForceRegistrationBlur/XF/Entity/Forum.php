<?php

namespace Wutime\ForceRegistrationBlur\XF\Entity;
use Wutime\ForceRegistrationBlur\Helper\Blur;

class Forum extends XFCP_Forum
{

	public function canCreateThread(&$error = null)
	{
		$canCreateThread = parent::canCreateThread($error);

        if (Blur::determineIsBlurForum($this->node_id) && \XF::options()->wutime_frb_remove_actions_forum) {
            return false;
        }

		return $canCreateThread;
	}

}
