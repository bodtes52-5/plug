<?php

namespace Wutime\ForceRegistrationBlur\XF\Entity;

use XF\Mvc\Entity\Structure;

class Post extends XFCP_Post
{

    public static function getStructure(Structure $structure)
    {
        $structure = parent::getStructure($structure);
        // register a runtime-only option we can toggle from the controller
        $structure->options['frb_is_blur_first_post'] = false;
        $structure->options['frb_is_blur'] = false;
        return $structure;
    }

    // optional convenience getter if you prefer calling $post->isBlur() in PHP/templates
    public function isBlur(): bool
    {
        return (bool)$this->getOption('frb_is_blur');
    }

    // optional convenience getter if you prefer calling $post->isBlur() in PHP/templates
    public function isBlurFirstPost(): bool
    {
        return (bool)$this->getOption('frb_is_blur_first_post');
    }

    public function invalidateActions() {

        if (\XF::options()->wutime_frb_remove_actions_post && method_exists($this->Thread, 'isBlur')) {
            if ($this->Thread->isBlur()) {
                return true;
            }
        }

        return false;
    }

    public function canReact(&$error = null)
    {
        $canReact = parent::canReact($error);

        if ($this->invalidateActions()) 
            return false;

        return $canReact;
    }

    public function canReport(&$error = null, ?\XF\Entity\User $asUser = null)
    {
        $canReport = parent::canReport($error, $asUser);

        if ($this->invalidateActions()) 
            return false;

        return $canReport;
    }

    public function canEdit(&$error = null)
    {
        $canEdit = parent::canEdit($error);

        if ($this->invalidateActions()) 
            return false;

        return $canEdit;
    }

    public function canDelete($type = 'soft', &$error = null)
    {
        $canDelete = parent::canDelete($type, $error);

        if ($this->invalidateActions()) 
            return false;

        return $canDelete;
    }


    public function isContentVotingSupported(): bool
    {
        $isVotingSupported = parent::isContentVotingSupported();

        if ($this->invalidateActions()) 
            return false;

        return $isVotingSupported;
    }

    public function isContentDownvoteSupported(): bool
    {
        $isDownvoteSupported = parent::isContentDownvoteSupported();

        if ($this->invalidateActions()) 
            return false;

        return $isDownvoteSupported;
    }

    protected function canVoteOnContentInternal(&$error = null): bool
    {
        $canVote = parent::canVoteOnContentInternal($error);

        if ($this->invalidateActions()) 
            return false;

        return $canVote;
    }

    public function canDownvoteContent(&$error = null): bool
    {
        $canDownvote = parent::canDownvoteContent($error);

        if ($this->invalidateActions()) 
            return false;

        return $canDownvote;
    }

    public function canMarkAsQuestionSolution(&$error = null): bool
    {
        $canMarkAsSolution = parent::canMarkAsQuestionSolution($error);

        if ($this->invalidateActions()) 
            return false;

        return $canMarkAsSolution;
    }
}
