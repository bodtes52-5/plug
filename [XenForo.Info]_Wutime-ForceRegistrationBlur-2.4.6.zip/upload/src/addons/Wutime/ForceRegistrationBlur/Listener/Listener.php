<?php

namespace Wutime\ForceRegistrationBlur\Listener;

use Jaybizzle\CrawlerDetect\CrawlerDetect;

class Listener
{   

    public static function appPubSetupDigitalPointCloudFlare(\XF\App $app): void
    {
        $addOn = \XF::app()->addonManager()->getById('DigitalPoint/Cloudflare');
        if ($addOn && $addOn->isActive()) {
            // Extend DP CF and make sure our pages aren't cached
            $app->extendClass('DigitalPoint\Cloudflare\XF\Template\Templater', 'Wutime\ForceRegistrationBlur\XF\Template\Templater');
        }
    }


    public static function handlePageCaching(\XF\App $app): void
    {
        $opt = \XF::options();

		if (!\XF\Pub\App::$allowPageCache) { return; }        // someone already disabled it this request

		$pc = $app->pageCache();
		if (!$pc || !$pc->isEnabled()) { return; }            // provider/context not usable

		$req = $app->request();
		if (!$req->isGet() || $req->isXhr()) { return; }      // won’t ever hit page cache

        // only relevant when blur is on AND you don't blur crawlers
        if (empty($opt->wutime_forceregblur_guest_osbfucate_post_text)
            || empty($opt->wutime_forceregblur_do_not_blur_crawlers)) {
            return;
        }

        // If implementation is guest-only OR visitor lacks the bypass permission,
        // then crawlers should NOT use page cache at all.
        $needsCrawlerVeto =
            ($opt->wutime_frb_implementation === 'Guest')
            || !\XF::visitor()->hasPermission('general', 'viewUnblurredContent');

        if (!$needsCrawlerVeto) {
            return;
        }

        // XF robot check first, then JayBizzle
        $req = $app->request();
        $isBot = (bool)$req->getRobotName();
        if (!$isBot) {
            static $detector;
            $detector ??= new CrawlerDetect();
            $isBot = $detector->isCrawler($req->getUserAgent() ?? '');
        }

        if ($isBot) {
            // This disables both serving from and saving to the guest page cache for this request.
            \XF\Pub\App::$allowPageCache = false;  // key line
        }
    }

}