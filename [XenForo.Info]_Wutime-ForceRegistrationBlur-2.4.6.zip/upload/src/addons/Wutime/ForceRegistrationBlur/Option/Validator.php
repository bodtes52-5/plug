<?php

namespace Wutime\ForceRegistrationBlur\Option;

use XF\Option\AbstractOption;

class Validator extends AbstractOption
{
    public static function validateGuestPageCachingAndSeo(&$value, \XF\Entity\Option $option, $optionId)
    {
        // Convert value to boolean
        $value = (bool) $value;

        // Check if enabling guest obfuscation
        if ($value) {


            // Check page caching 
            /*
            $config = \XF::app()->config();
            if (!empty($config['pageCache']['enabled'])) {
                $option->error(\XF::phrase('wutime_forcereg_option_validate_guest_page_caching'), $optionId);
                return false;
            }
            */

            // Check crawler setting
            $doNotBlurCrawlers = \XF::options()->wutime_forceregblur_do_not_blur_crawlers;
            if (!$doNotBlurCrawlers) {
                $option->error(\XF::phrase('wutime_forceregblur_seo_warning_message'), $optionId);
                return false;
            }
        }

        return true;
    }

    public static function validateCrawlerBlur(&$value, \XF\Entity\Option $option, $optionId)
    {
        // Convert value to boolean
        $value = (bool) $value;

        // Check if disabling crawler blur prevention
        if (!$value) {
            $guestObfuscate = \XF::options()->wutime_forceregblur_guest_osbfucate_post_text;
            if ($guestObfuscate) {
                $option->error(\XF::phrase('wutime_forceregblur_seo_warning_message'), $optionId);
                return false;
            }
        }

        return true;
    }
}