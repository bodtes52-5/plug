<?php
namespace Wutime\ForceRegistrationBlur\Callbacks;

class Options {

    public static function verifyNumberComma(&$value, \XF\Entity\Option $option, $optionId)
    {      
        $value = str_replace(' ', '', $value);

        if (preg_match('/^\d+(?:,\d+)*$/',$value) || $value === '')
        {
            return true;
        }
        
        $option->error(\XF::phrase('wutime_forcereg_blur_option_must_be_number_comma'));
        return false;
    }

}
