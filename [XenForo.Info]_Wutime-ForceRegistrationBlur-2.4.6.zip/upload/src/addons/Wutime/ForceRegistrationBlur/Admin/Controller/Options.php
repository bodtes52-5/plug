<?php

namespace Wutime\ForceRegistrationBlur\Admin\Controller;

use XF\Admin\Controller\AbstractController;
use XF\Mvc\ParameterBag;

class Options extends AbstractController
{
    public function actionWarning()
    {
        $viewParams = [
            'option_id' => 'wutime_forceregblur_do_not_blur_crawlers'
        ];

        return $this->view(
            'Wutime\ForceRegistrationBlur:Options\SeoWarning',
            'wutime_forceregblur_seo_warning',
            $viewParams
        );
    }
}