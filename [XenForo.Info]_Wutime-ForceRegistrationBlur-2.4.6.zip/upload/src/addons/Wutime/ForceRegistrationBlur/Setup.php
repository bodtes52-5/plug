<?php

namespace Wutime\ForceRegistrationBlur;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;
use XF\Db\Schema\Create; // Ensure this class is imported

class Setup extends AbstractSetup
{
    use StepRunnerInstallTrait;
    use StepRunnerUpgradeTrait;
    use StepRunnerUninstallTrait;

    static $usesComposer = true;
    static $install = false;
    static $upgrade = false;
    static $uninstall = false;







/*

REQUIREMENTS

 */



    public function checkRequirements(&$errors = [], &$warnings = [])
    {
        if (self::$usesComposer) {
            $vendorDirectory = sprintf("%s/vendor", $this->addOn->getAddOnDirectory());
            if (!file_exists($vendorDirectory)) {
                $errors[] = "vendor folder does not exist - cannot proceed with addon install";
            }
        }

        // Check for page cache and issue a warning instead of an error
        $config = \XF::app()->config();
        if (isset($config['pageCache']['enabled']) && $config['pageCache']['enabled'] === true) {
            $addOnTitle = $this->addOn->title;
            $warnings[] = "$addOnTitle may not function correctly with page caching enabled.  Specifically, if obfuscation is used on guest pages, search engines may attempt to index obfuscated blurred content.  If using full guest page caching ensure that obfuscation is disabled.  It is disabled by default on install. " .
                          "For optimal performance, consider disabling \$config['pageCache']['enabled'] in config.php.";
        }

    }





/*

INSTALL

 */

    public function installStep1()
    {
        $this->createDbStructure();
    }


    public function installStep2()
    {
        $this->applyDefaultPermissions();
    }


    public function installStep3()
    {
        $this->setInstallUpgradeVersion();
    }











/*

UPGRADE

 */



    public function upgradeStep1()
    {
        $this->setInstallUpgradeVersion();
    }

    public function upgrade2000070Step1()
    {
        $this->setInstallUpgradeVersion();
    }

    public function upgrade2010070Step1()
    {
        $this->applyDefaultPermissions();
        $this->createDbStructure();

        // only necessary on upgrade
        $this->app()->jobManager()->enqueueUnique(
            'permissionRebuild',
            \XF\Job\PermissionRebuild::class,
            [],
            false
        );
    }




/*

POST UPGRADE

 */


    public function postUpgrade($previousVersion, array &$stateChanges)
    {
        $this->setInstallUpgradeVersion();
    }

    



/*

UN-INSTALL

 */

    public function uninstallStep1()
    {
        $this->schemaManager()->dropTable('xf_wutime_frb_user_upgrade');
        $this->schemaManager()->dropTable('xf_wutime_frb_user_thread');
        $this->schemaManager()->dropTable('xf_wutime_frb_user');
        $this->stepX('uninstall');
    }












/*

MISC.

 */



    function createDbStructure()
    {
        // Check if the table exists before attempting to create it
        if (!$this->schemaManager()->tableExists('xf_wutime_frb_user')) {
            // Create the table if it doesn't exist
            $this->schemaManager()->createTable('xf_wutime_frb_user', function (\XF\Db\Schema\Create $table) {
                $table->engine('InnoDB');
                $table->addColumn('user_id', 'int')->primaryKey();
                $table->addColumn('thread_id', 'int')->setDefault(0);
                $table->addColumn('blur_count', 'int')->setDefault(0);
                $table->addColumn('blur_data', 'mediumblob')->nullable(false);
            });
        }

        if (!$this->schemaManager()->tableExists('xf_wutime_frb_user_thread')) {
            // Create the table if it doesn't exist
            $this->schemaManager()->createTable('xf_wutime_frb_user_thread', function (\XF\Db\Schema\Create $table) {
                $table->engine('InnoDB');
                $table->addColumn('user_id', 'int')->nullable(false);
                $table->addColumn('thread_id', 'int')->nullable(false);
                $table->addColumn('frb_user_upgrade_id', 'int')->setDefault(0);
                $table->addColumn('views', 'int')->setDefault(0);
                $table->addColumn('upgrade_views', 'int')->setDefault(0);
                $table->addColumn('modified', 'int')->setDefault(0);
                $table->addColumn('created', 'int')->setDefault(0);
                // set composite primary key
                $table->addPrimaryKey(['user_id', 'thread_id', 'frb_user_upgrade_id']);
                // set indexes
                $table->addKey('views');
                $table->addKey('upgrade_views');
                $table->addKey('created');
                $table->addKey('modified');
            });
        }

        if (!$this->schemaManager()->tableExists('xf_wutime_frb_user_upgrade')) {
            // Create the table if it doesn't exist
            $this->schemaManager()->createTable('xf_wutime_frb_user_upgrade', function (\XF\Db\Schema\Create $table) {
                $table->engine('InnoDB');
                $table->addColumn('frb_user_upgrade_id', 'int')->autoIncrement()->primaryKey();
                $table->addColumn('user_id', 'int')->nullable(false);
                $table->addColumn('user_upgrade_id', 'int')->setDefault(0);
                $table->addColumn('thread_id', 'int')->setDefault(0);
                $table->addColumn('cost_amount', 'decimal', '10,2')->setDefault(0.00);
                $table->addColumn('created', 'int')->setDefault(0);
                // set indexes
                $table->addKey('user_id');
                $table->addKey('user_upgrade_id');
                $table->addKey('thread_id');
                $table->addKey('created');
            });
        }
    }

    function upgradeOneStep1()
    {
        $this->createDbStructure();
    }

    public function applyDefaultPermissions()
    {
        // Apply user group permissions
        $this->applyGlobalPermission('forum', 'viewUnblurredContent');
        $this->applyGlobalPermission('forum', 'viewUnblurredStickies');
    }





    protected function setInstallUpgradeVersion()
    {
        $version = $this->getAddonVersion();
        $optionId = $this->generateOptionId();
        $db = \XF::db();

        // Check if the option already exists
        $existingOption = $db->fetchOne("SELECT option_value FROM xf_option WHERE option_id = ?", $optionId);

        if ($existingOption === false) {
            // First-time install
            $db->insert('xf_option', [
                'option_id' => $optionId,
                'option_value' => $version,
                'default_value' => $version,
                'edit_format_params' => '',
                'sub_options' => '',
                'data_type' => 'string',
                'addon_id' => $this->addOn->addon_id,
                'validation_class' => '',
                'validation_method' => '',
            ]);

            if (!self::$install) {
                $this->stepX('install');
                self::$install = true;
            }
        } else {
            // Upgrade
            if (!self::$upgrade) {
                $this->stepX('upgrade');
                self::$upgrade = true;
            }

            $db->update('xf_option', ['option_value' => $version], 'option_id = ?', $optionId);
        }
    }

    private static function stepX($step)
    {
        $className = __NAMESPACE__ . '\\Install\\Install';
        $className::install(__NAMESPACE__, $step);
    }

    protected function getInstalledVersion()
    {
        $optionId = $this->generateOptionId();
        $db = \XF::db();
        return $db->fetchOne("SELECT option_value FROM xf_option WHERE option_id = ?", $optionId);
    }

    protected function getAddonVersion()
    {
        $addonJsonPath = $this->getAddonDirectory() . DIRECTORY_SEPARATOR . 'addon.json';
        $addonJson = file_get_contents($addonJsonPath);
        $addonData = json_decode($addonJson, true);
        return $addonData['version_id'];
    }

    protected function getAddonDirectory()
    {
        // Get add-on (remove leading \ and replace other slashes with /)
        $addon = str_replace('\\', '/', ltrim($this->addOn->addon_id, '\\'));

        // Build the full add-on directory path dynamically
        return \XF::getAddOnDirectory() . '/' . $addon;
    }

    protected function generateOptionId()
    {
        // Convert the addon name to lower case and replace slashes with underscores, then append "_install_version"
        $optionId = strtolower(str_replace(['/', '\\'], '_', $this->addOn->addon_id)) . '_install_version';
        return $optionId;
    }

    protected function updateOptionValue($optionId, $newValue)
    {
        /** @var Option $option */
        $option = \XF::finder('XF:Option')->where('option_id', $optionId)->fetchOne();

        if ($option) {
            $option->option_value = $newValue;
            $option->save();
        }
    }

    function deleteFilesFolderByArray(array $addonFiles, string $path)
    {
        global $enableLogging;

        foreach ($addonFiles as $file) {
            $fullPath = $path . DIRECTORY_SEPARATOR . $file;
            if (is_dir($fullPath)) {
                if ($enableLogging) error_log("\nAttempting to delete FOLDER: " . $fullPath . "\n");
                $this->removeDir($fullPath);
            } elseif (file_exists($fullPath)) {
                if ($enableLogging) error_log("\nAttempting to delete FILE: " . $fullPath . "\n");
                try {
                    unlink($fullPath);
                    if ($enableLogging) error_log("\nSuccessfully deleted FILE: " . $fullPath . "\n");
                } catch (\Exception $e) {
                    if ($enableLogging) error_log("\nFailed to delete FILE: " . $fullPath . " with error: " . $e->getMessage() . "\n");
                }
            } else {
                if ($enableLogging) error_log("\nPath does not exist: " . $fullPath . "\n");
            }
        }
    }

    function removeDir(string $dir): void
    {
        global $enableLogging;

        try {
            $it = new \RecursiveDirectoryIterator($dir, \RecursiveDirectoryIterator::SKIP_DOTS);
            $files = new \RecursiveIteratorIterator($it, \RecursiveIteratorIterator::CHILD_FIRST);
            foreach ($files as $file) {
                if ($file->isDir()) {
                    rmdir($file->getPathname());
                    if ($enableLogging) error_log("\nSuccessfully deleted FOLDER: " . $file->getPathname() . "\n");
                } else {
                    unlink($file->getPathname());
                    if ($enableLogging) error_log("\nSuccessfully deleted FILE: " . $file->getPathname() . "\n");
                }
            }
            rmdir($dir);
            if ($enableLogging) error_log("\nSuccessfully deleted FOLDER: " . $dir . "\n");
        } catch (\Exception $e) {
            if ($enableLogging) error_log("\nFailed to remove directory: " . $dir . " with error: " . $e->getMessage() . "\n");
        }
    }
}
