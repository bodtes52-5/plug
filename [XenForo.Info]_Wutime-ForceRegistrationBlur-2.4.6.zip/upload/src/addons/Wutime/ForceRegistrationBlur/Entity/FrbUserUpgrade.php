<?php

namespace Wutime\ForceRegistrationBlur\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

use XF\Service;
use XF\Service\User;

class FrbUserUpgrade extends Entity
{
    public static function getStructure(Structure $structure)
    {
        $structure->table = 'xf_wutime_frb_user_upgrade';
        $structure->shortName = 'Wutime\ForcedRegistrationBlur:FrbUserUpgrade';
        $structure->primaryKey = 'frb_user_upgrade_id';
        $structure->columns = [
            'frb_user_upgrade_id' => ['type' => self::UINT, 'autoIncrement' => true],
            'user_id' => ['type' => self::UINT, 'required' => true],
            'user_upgrade_id' => ['type' => self::UINT, 'required' => true, 'default' => 0],
            'thread_id' => ['type' => self::UINT, 'required' => true, 'default' => 0],
            'cost_amount' => ['type' => self::FLOAT, 'required' => true, 'default' => 0.00],
            'created' => ['type' => self::UINT, 'required' => true, 'default' => 0],
        ];
        $structure->getters = [];
        $structure->relations = [
            'User' => [
                'entity' => 'XF:User',
                'type' => self::TO_ONE,
                'conditions' => 'user_id',
                'primary' => true
            ]
        ];

        return $structure;
    }

    protected function _postSave()
    {
        $db = \XF::db();

        $sql = "
            UPDATE xf_wutime_frb_user_thread
            SET frb_user_upgrade_id = ?
            WHERE user_id = ? AND frb_user_upgrade_id = 0
        ";

        $db->query($sql, [$this->frb_user_upgrade_id, $this->user_id]);

        // Remove the session variable
        $session = \XF::session();
        $session->remove('wutime_frb_user_blur_data');
    }


    protected function setupDefaults()
    {
        parent::setupDefaults();
        $this->created = \XF::$time;
    }
}