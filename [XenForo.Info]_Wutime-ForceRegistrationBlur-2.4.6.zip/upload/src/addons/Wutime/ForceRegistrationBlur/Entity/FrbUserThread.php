<?php

namespace Wutime\ForceRegistrationBlur\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

class FrbUserThread extends Entity
{
    public static function getStructure(Structure $structure)
    {
        $structure->table = 'xf_wutime_frb_user_thread';
        $structure->shortName = 'Wutime\ForceRegistrationBlur:FrbUserThread';
        $structure->primaryKey = ['user_id', 'thread_id', 'frb_user_upgrade_id'];
        $structure->columns = [
            'user_id' => ['type' => self::UINT, 'required' => true],
            'thread_id' => ['type' => self::UINT, 'required' => true],
            'frb_user_upgrade_id' => ['type' => self::UINT, 'default' => 0],
            'views' => ['type' => self::UINT, 'default' => 0],
            'upgrade_views' => ['type' => self::UINT, 'default' => 0],
            'modified' => ['type' => self::UINT, 'default' => 0],
            'created' => ['type' => self::UINT, 'default' => 0],
        ];
        $structure->getters = [];
        $structure->relations = [
            'User' => [
                'entity' => 'XF:User',
                'type' => self::TO_ONE,
                'conditions' => 'user_id',
                'primary' => true
            ],
            'Thread' => [
                'entity' => 'XF:Thread',
                'type' => self::TO_ONE,
                'conditions' => 'thread_id',
                'primary' => true
            ],
            'FrbUserUpgrade' => [
                'entity' => 'Wutime\ForceRegistrationBlur:FrbUserUpgrade',
                'type' => self::TO_ONE,
                'conditions' => 'frb_user_upgrade_id',
                'primary' => true
            ]
        ];

        return $structure;
    }


    public static function saveUpgradeView($threadId)
    {
        $em = \XF::em();
        $userId = \XF::visitor()->user_id;

        // Try to find existing entity
        $FrbUserEntity = $em->findOne('Wutime\ForceRegistrationBlur:FrbUserThread', [
            'user_id' => $userId,
            'thread_id' => $threadId,
            'frb_user_upgrade_id' => 0
        ]);

        if ($FrbUserEntity) 
        {
            $FrbUserEntity->upgrade_views++;
            $FrbUserEntity->modified = \XF::$time;
            $FrbUserEntity->save();
        }
    }

    public static function saveThreadView($threadId)
    {
        $em = \XF::em();
        $userId = \XF::visitor()->user_id;

        // Try to find existing entity
        $FrbUserEntity = $em->findOne('Wutime\ForceRegistrationBlur:FrbUserThread', [
            'user_id' => $userId,
            'thread_id' => $threadId,
            'frb_user_upgrade_id' => 0
        ]);

        if ($FrbUserEntity) {
            // Entity exists, increment views and update modified time
            $FrbUserEntity->views++;
            $FrbUserEntity->modified = \XF::$time;
        } else {
            // Entity does not exist, create a new one
            $FrbUserEntity = $em->create('Wutime\ForceRegistrationBlur:FrbUserThread');
            $FrbUserEntity->user_id = $userId;
            $FrbUserEntity->thread_id = $threadId;
            $FrbUserEntity->frb_user_upgrade_id = 0;
            $FrbUserEntity->views = 1;
            $FrbUserEntity->created = \XF::$time;
            $FrbUserEntity->modified = \XF::$time;
        }

        // Save the entity
        $FrbUserEntity->save();
    }

    public static function getMostRecentlyModifiedUpgradeViewThreadId()
    {
        $FrbUserThread = \XF::finder('Wutime\ForceRegistrationBlur:FrbUserThread')
            ->where('upgrade_views', '>', 0)
            ->order('modified', 'DESC')
            ->fetchOne();


        if ($FrbUserThread)
            return $FrbUserThread->thread_id;
        else
            return false;
    }
}
