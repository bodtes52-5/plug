<?php

namespace Wutime\ForceRegistrationBlur\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

class FrbUser extends Entity
{
    public static function getStructure(Structure $structure)
    {
        $structure->table = 'xf_wutime_frb_user';
        $structure->shortName = 'Wutime\ForceRegistrationBlur:FrbUser';
        $structure->primaryKey = 'user_id';
        $structure->contentType = 'frb_user';

        $structure->columns = [
            'user_id' => ['type' => self::UINT, 'required' => true],
            'thread_id' => ['type' => self::UINT, 'default' => 0],
            'blur_count' => ['type' => self::UINT, 'default' => 0],
            'blur_data' => ['type' => self::JSON, 'required' => true, 'default' => []],
        ];
        $structure->getters = [];
        $structure->relations = [
            'User' => [
                'entity' => 'XF:User',
                'type' => self::TO_ONE,
                'conditions' => 'user_id',
                'primary' => true
            ]
        ];

        return $structure;
    }
    

}
