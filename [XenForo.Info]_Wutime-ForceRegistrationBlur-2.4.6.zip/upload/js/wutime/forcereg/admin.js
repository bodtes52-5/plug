document.addEventListener('DOMContentLoaded', function() {
    // Get the ID of the active tab from localStorage
    var activeTabId = localStorage.getItem('activeTabId');

    if (activeTabId) {
        // Find the tab with the stored ID
        var activeTab = document.querySelector('.tabs-tab[aria-controls="' + activeTabId + '"]');

        // Remove is-active from all tabs and set aria-selected="false"
        document.querySelectorAll('.tabs-tab').forEach(function(tab) {
            tab.classList.remove('is-active');
            tab.setAttribute('aria-selected', 'false');
        });

        // Add is-active to the selected tab and set aria-selected="true"
        if (activeTab) {
            activeTab.classList.add('is-active');
            activeTab.setAttribute('aria-selected', 'true');

            // Find and activate the corresponding tab content
            var tabContent = document.getElementById(activeTabId);
            if (tabContent) {
                document.querySelectorAll('.block-body').forEach(function(content) {
                    content.classList.remove('is-active');
                });
                tabContent.classList.add('is-active');
            }
        }
    }

    // Event listener to store the active tab whenever a tab is clicked
    document.querySelectorAll('.tabs-tab').forEach(function(tab) {
        tab.addEventListener('click', function() {
            // Store the ID of the active tab in localStorage
            var activeTabId = this.getAttribute('aria-controls');
            localStorage.setItem('activeTabId', activeTabId);

            // Set aria-selected="false" for all tabs
            document.querySelectorAll('.tabs-tab').forEach(function(t) {
                t.setAttribute('aria-selected', 'false');
            });

            // Set aria-selected="true" for the clicked tab
            this.setAttribute('aria-selected', 'true');
        });
    });

    // Optional: Clear the stored tab after form submission
    document.querySelector('form').addEventListener('submit', function() {
        localStorage.removeItem('activeTabId');
    });
});



(function () {
  function run() {
    var radioUsers  = document.querySelector('input[name="options[wutime_frb_implementation]"][value="Users"]');
    var radioGuests = document.querySelector('input[name="options[wutime_frb_implementation]"][value="Guests"]');
    if (!radioUsers && !radioGuests) return;

    // Non-tab layout groups (may not exist when using tabs)
    var group1000 = document.getElementById('option-group-1000');
    var group2000 = document.getElementById('option-group-2000');
    var group4000 = document.getElementById('option-group-4000');
    var group5000 = document.getElementById('option-group-5000');

    // Tabs layout (may not exist when not using tabs)
    var header = document.querySelector('h2.block-tabHeader[role="tablist"]');
    function tab(num)  { return header ? header.querySelector('.tabs-tab[aria-controls="pane-' + num + '"]') : null; }
    function pane(num) { return document.getElementById('pane-' + num); }

    var t1000 = tab(1000), p1000 = pane(1000);
    var t2000 = tab(2000), p2000 = pane(2000);
    var t4000 = tab(4000), p4000 = pane(4000);
    var t5000 = tab(5000), p5000 = pane(5000);

    function setDisplay(el, on) { if (el) el.style.display = on ? '' : 'none'; }
    function setGroupVisible(el, on) { setDisplay(el, on); }
    function setTabPaneVisible(p, t, on) { setDisplay(p, on); setDisplay(t, on); }

    // Option anchors (span ids) for the 4 checkboxes
    var optionIds = [
      'wutime_forcereg_blur_threadlist_title',
      'wutime_forcegreg_disable_thread_snippet_overlay',
      'wutime_forcegreg_blur_post_bit',
      'wutime_forcegreg_disable_post_member_overlay'
    ];

    function setOptionsVisible(on) {
      optionIds.forEach(function(id) {
        var anchor = document.getElementById(id);
        if (anchor) {
          // the <dl.formRow> is the next sibling
          var row = anchor.nextElementSibling;
          if (row && row.classList.contains('formRow')) {
            row.style.display = on ? '' : 'none';
          }
          // optionally hide the anchor itself
          anchor.style.display = on ? '' : 'none';
        }
      });
    }

    function flashElement(el) {
      if (!el) return;
      el.classList.add('flash');
      setTimeout(function(){ el.classList.remove('flash'); }, 2000);
    }

    function ensureActiveTabVisible() {
      if (!header) return; // only relevant for tabs layout
      var active = header.querySelector('.tabs-tab.is-active');
      if (active && active.style.display === 'none') {
        var first = Array.from(header.querySelectorAll('.tabs-tab')).find(function(a){ return a.style.display !== 'none'; });
        if (first) first.click();
      }
      if (window.XF && XF.layoutChange) XF.layoutChange();
    }

    function updateVisibility(flash) {
      if (radioGuests && radioGuests.checked) {
        // Guests
        setGroupVisible(group1000, true);
        setGroupVisible(group4000, false);
        setGroupVisible(group5000, false);

        setTabPaneVisible(p1000, t1000, true);
        setTabPaneVisible(p4000, t4000, false);
        setTabPaneVisible(p5000, t5000, false);

        // hide the 4 option rows entirely
        setOptionsVisible(false);

        if (flash) {
          flashElement(group1000); flashElement(group2000);
          flashElement(p1000);     flashElement(p2000);
        }
      } else if (radioUsers && radioUsers.checked) {
        // Users
        setGroupVisible(group1000, false);
        setGroupVisible(group4000, true);
        setGroupVisible(group5000, true);

        setTabPaneVisible(p1000, t1000, false);
        setTabPaneVisible(p4000, t4000, true);
        setTabPaneVisible(p5000, t5000, true);

        // show the 4 option rows again
        setOptionsVisible(true);

        if (flash) {
          flashElement(group1000); flashElement(group2000);
          flashElement(group4000); flashElement(group5000);
          flashElement(p1000);     flashElement(p2000);
          flashElement(p4000);     flashElement(p5000);
        }
      }
      ensureActiveTabVisible();
    }

    // Initial pass (no flash)
    updateVisibility(false);

    // Change handlers (with flash)
    [radioUsers, radioGuests].forEach(function(r){
      if (r) r.addEventListener('change', function(){ updateVisibility(true); });
    });
  }

  if (window.XF && XF.on) {
    XF.on(document, 'xf:ready', run);
    XF.on(document, 'xf:reinit', run);
  } else {
    document.addEventListener('DOMContentLoaded', run);
  }
})();
