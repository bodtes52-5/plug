/* frb_sticky.js */
(function () {
  // Find the FIRST FRB notice on the page (if multiple exist)
  var els = document.querySelectorAll('.wutime-frb-stickable');
  if (!els || !els.length) return;
  var el = els[0];

  var stickyOnScroll = el.dataset.stickyOnScroll === '1';
  var stickyOnMobile = el.dataset.stickyOnMobile === '1';
  var mqMobile = window.matchMedia('(max-width: 768px)');

  // Create a stable anchor before the bar so our trigger point
  // doesn't move when the bar switches to position: fixed.
  var anchor = document.createElement('div');
  anchor.className = 'frb-anchor';
  el.parentNode.insertBefore(anchor, el);

  var stickAt = 0;     // when anchor touches the top
  var unstickAt = 10;  // 50px band to avoid thrash

  // tracks if scroll-based sticky is allowed (disabled on mobile)
  var allowScrollSticky = false;

  // track current state to avoid redundant DOM writes
  var isStuck = false;

  function setStuck(stuck) {
    if (stuck === isStuck) return;
    isStuck = stuck;

    el.classList.toggle('is-stuck', stuck);
    document.documentElement.classList.toggle('has-sticky-frbWarn', stuck);

    if (stuck) {
      var h = el.offsetHeight || 64;
      document.documentElement.style.setProperty('--frbWarnH', h + 'px');
      anchor.style.height = h + 'px'; // prevent layout jump
    } else {
      document.documentElement.style.removeProperty('--frbWarnH');
      anchor.style.height = '';
    }
  }

  function recomputeModes() {
    // scroll sticky only if option is on AND not mobile
    allowScrollSticky = stickyOnScroll && !mqMobile.matches;

    // Mobile behavior
    if (stickyOnMobile && mqMobile.matches) {
      setStuck(true);
      return; // mobile wins; ignore scroll logic
    }

    // If neither mobile nor scroll sticky is allowed, unstick
    if (!allowScrollSticky) {
      setStuck(false);
    }
  }

  var ticking = false;
  function onScroll() {
    if (!allowScrollSticky) return;

    if (!ticking) {
      ticking = true;
      requestAnimationFrame(function () {
        ticking = false;

        var top = anchor.getBoundingClientRect().top;

        if (!isStuck && top <= stickAt) {
          setStuck(true);
        } else if (isStuck && top > unstickAt) {
          setStuck(false);
        }
      });
    }
  }

  // Init
  recomputeModes();
  onScroll();

  // Events
  if (stickyOnScroll) {
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  var mqHandler = function () {
    recomputeModes();
    onScroll();
  };
  if (mqMobile.addEventListener) {
    mqMobile.addEventListener('change', mqHandler);
  } else {
    mqMobile.addListener(mqHandler); // older Safari
  }
  window.addEventListener('resize', mqHandler);

  // Keep padding in sync if bar height changes dynamically
  if ('ResizeObserver' in window) {
    new ResizeObserver(function () {
      if (isStuck) {
        // Recompute height if the bar's height changes while stuck
        var h = el.offsetHeight || 64;
        document.documentElement.style.setProperty('--frbWarnH', h + 'px');
        anchor.style.height = h + 'px';
      }
    }).observe(el);
  }
})();
